<aside>
  <div id="sidebar"  class="nav-collapse ">
    <ul class="sidebar-menu" id="nav-accordion">
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-laptop"></i>
          <span>Cadastros</span>
        </a>
        <ul class="sub">
          <li><a  href="http://<?php echo APP_HOST; ?>/empresa/cadastrar">Empresa</a></li>
          <li><a  href="http://<?php echo APP_HOST; ?>/tecnologia/cadastrar">Tecnologia</a></li>
          <li><a  href="http://<?php echo APP_HOST; ?>/vaga/cadastrar">Vaga</a></li>
        </ul>
      </li>
      <li class="sub-menu">
        <a href="javascript:;">
          <i class="fa fa-laptop"></i>
          <span>Listagem</span>
        </a>
        <ul class="sub">
          <li><a  href="http://<?php echo APP_HOST; ?>/empresa/listar">Empresas</a></li>
          <li><a  href="http://<?php echo APP_HOST; ?>/tecnologia/listar">Tecnologias</a></li>
          <li><a  href="http://<?php echo APP_HOST; ?>/vaga/listar">Vagas</a></li>
        </ul>
      </li>
    </ul>
  </div>
</aside>
<header class="header white-bg">  
	<div class="sidebar-toggle-box">
		<div data-original-title="Toggle Navigation" data-placement="right" class="fa fa-bars tooltips"></div>
	</div>
	<a href="http://<?php echo APP_HOST; ?>" class="logo">DEVMEDIA - PHP </a>
</header>
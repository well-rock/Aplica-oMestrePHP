</section>
<script src="http://<?php echo APP_HOST; ?>/public/js/jquery.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/bootstrap.min.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/jquery.maskedinput.js" type="text/javascript"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/validacao-empresa.js" type="text/javascript"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/validacao-tecnologia.js" type="text/javascript"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/validacao-vaga.js" type="text/javascript"></script>
<script class="include" type="text/javascript" src="http://<?php echo APP_HOST; ?>/public/js/jquery.dcjqaccordion.2.7.js"></script>

<script src="http://<?php echo APP_HOST; ?>/public/js/common-scripts.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/js/jquery.easy-autocomplete.min.js"></script> 
<script src="http://<?php echo APP_HOST; ?>/public/js/autocomplete-empresa.js"></script> 
<script src="http://<?php echo APP_HOST; ?>/public/js/autocomplete-tecnologia.js"></script> 
</body>
</html>
